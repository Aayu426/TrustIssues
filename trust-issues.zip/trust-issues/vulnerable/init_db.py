"""Creates and seeds vulnerable.db. Passwords are stored in PLAINTEXT on
purpose (pairs with the SQLi + brute force + info-disclosure demos)."""
import sqlite3
import os


def run(db_path):
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path)
    c = conn.cursor()

    c.executescript("""
    CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT,
        role TEXT,
        full_name TEXT,
        email TEXT,
        bio TEXT
    );

    CREATE TABLE events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        description TEXT,
        event_date TEXT,
        location TEXT,
        created_by INTEGER
    );

    CREATE TABLE registrations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        event_id INTEGER,
        notes TEXT,
        registered_at TEXT
    );

    CREATE TABLE comments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_id INTEGER,
        user_id INTEGER,
        content TEXT,
        created_at TEXT
    );
    """)

    admins = [
        ("admin1", "admin123", "admin", "Priya Sharma", "priya.admin@ccvit.club"),
        ("admin2", "admin456", "admin", "Rahul Nair", "rahul.admin@ccvit.club"),
        ("root", "toor", "admin", "Root Superuser", "root@ccvit.club"),
    ]
    members = [
        ("alice", "alice123", "member", "Alice Fernandes", "alice@ccvit.club"),
        ("bob", "bob123", "member", "Bob Mathew", "bob@ccvit.club"),
        ("carol", "carol123", "member", "Carol D'Souza", "carol@ccvit.club"),
        ("dave", "dave123", "member", "Dave Menon", "dave@ccvit.club"),
        ("erin", "erin123", "member", "Erin Thomas", "erin@ccvit.club"),
        ("frank", "frank123", "member", "Frank Pinto", "frank@ccvit.club"),
        ("grace", "grace123", "member", "Grace Kurian", "grace@ccvit.club"),
    ]
    for u in admins + members:
        c.execute(
            "INSERT INTO users (username, password, role, full_name, email, bio) VALUES (?, ?, ?, ?, ?, ?)",
            (u[0], u[1], u[2], u[3], u[4], f"Hi, I'm {u[3].split()[0]}!"),
        )

    events = [
        ("Welcome Mixer", "Kick-off event for new members.", "2026-11-05", "Seminar Hall A", 1),
        ("CTF Night", "Beginner-friendly capture-the-flag.", "2026-11-18", "Lab 204", 1),
        ("Capstone Demo Day", "Members present their projects.", "2026-12-02", "Auditorium", 2),
    ]
    for e in events:
        c.execute(
            "INSERT INTO events (title, description, event_date, location, created_by) VALUES (?, ?, ?, ?, ?)",
            e,
        )

    conn.commit()
    conn.close()
    print(f"Seeded DB at {db_path}")


if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__))
    run(os.path.join(here, "db", "vulnerable.db"))
