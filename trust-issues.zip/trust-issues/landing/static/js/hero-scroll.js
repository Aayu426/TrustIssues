// Scroll-scrubbed frame-sequence hero (Apple-style), driven by scroll position
// inside the #hero section (which is 300vh tall; canvas is position:sticky).
(function () {
  const canvas = document.getElementById('hero-canvas');
  const ctx = canvas.getContext('2d');
  const FRAME_COUNT = 240;
  const frames = [];
  let loaded = 0;
  let currentFrame = 0;

  function frameSrc(i) {
    const n = String(i).padStart(3, '0');
    return `static/hero_frames/frame_${n}.jpg`;
  }

  function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    render();
  }

  function render() {
    const img = frames[currentFrame];
    if (!img || !img.complete) return;
    const cw = canvas.width, ch = canvas.height;
    const iw = img.width, ih = img.height;
    const scale = Math.max(cw / iw, ch / ih);
    const dw = iw * scale, dh = ih * scale;
    const dx = (cw - dw) / 2, dy = (ch - dh) / 2;
    ctx.fillStyle = '#060a10';
    ctx.fillRect(0, 0, cw, ch);
    ctx.drawImage(img, dx, dy, dw, dh);
  }

  // Preload frames
  for (let i = 1; i <= FRAME_COUNT; i++) {
    const img = new Image();
    img.src = frameSrc(i);
    img.onload = () => { loaded++; if (i === 1) render(); };
    frames.push(img);
  }

  function onScroll() {
    const hero = document.getElementById('hero');
    const rect = hero.getBoundingClientRect();
    const total = hero.offsetHeight - window.innerHeight;
    const scrolled = -rect.top;
    let progress = total > 0 ? scrolled / total : 0;
    progress = Math.min(Math.max(progress, 0), 1);
    const frameIdx = Math.min(FRAME_COUNT - 1, Math.floor(progress * FRAME_COUNT));
    if (frameIdx !== currentFrame) {
      currentFrame = frameIdx;
      render();
    }
  }

  window.addEventListener('resize', resizeCanvas);
  window.addEventListener('scroll', onScroll, { passive: true });
  resizeCanvas();
})();
