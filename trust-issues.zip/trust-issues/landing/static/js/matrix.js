// Lightweight "cmatrix" style digital rain, rendered behind everything.
(function () {
  const canvas = document.getElementById('matrix-bg');
  const ctx = canvas.getContext('2d');
  let w, h, columns, drops;
  const glyphs = "アイウエオカキクケコサシスセソ0123456789ABCDEF$#%&@*+-/\\<>[]{}".split('');

  function resize() {
    w = canvas.width = window.innerWidth;
    h = canvas.height = document.documentElement.scrollHeight;
    columns = Math.floor(w / 16);
    drops = new Array(columns).fill(0).map(() => Math.random() * -100);
  }
  window.addEventListener('resize', resize);
  resize();

  function draw() {
    ctx.fillStyle = 'rgba(6,10,16,0.08)';
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#39ff6a';
    ctx.font = '14px monospace';
    for (let i = 0; i < drops.length; i++) {
      const char = glyphs[Math.floor(Math.random() * glyphs.length)];
      ctx.fillText(char, i * 16, drops[i] * 16);
      if (drops[i] * 16 > h && Math.random() > 0.975) drops[i] = 0;
      drops[i]++;
    }
    requestAnimationFrame(draw);
  }
  draw();
})();
