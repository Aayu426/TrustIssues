"""Creates and seeds app.db for the SECURED build. Passwords are hashed
(werkzeug generate_password_hash)."""
import sqlite3
import os
from werkzeug.security import generate_password_hash


def run(db_path):
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path)
    c = conn.cursor()

    c.executescript("""
    CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT,
        role TEXT,
        full_name TEXT,
        email TEXT,
        bio TEXT,
        failed_attempts INTEGER DEFAULT 0,
        locked_until REAL DEFAULT 0,
        session_version INTEGER DEFAULT 1
    );

    CREATE TABLE events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        description TEXT,
        event_date TEXT,
        location TEXT,
        created_by INTEGER
    );

    CREATE TABLE registrations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        event_id INTEGER,
        notes TEXT
    );

    CREATE TABLE comments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_id INTEGER,
        user_id INTEGER,
        content TEXT
    );

    CREATE TABLE uploads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        filename TEXT,
        original_name TEXT
    );

    CREATE TABLE chat_documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        filename TEXT,
        content TEXT
    );
    """)

    admins = [
        ("admin1", "admin123", "admin", "Priya Sharma", "priya.admin@ccvit.club"),
        ("admin2", "admin456", "admin", "Rahul Nair", "rahul.admin@ccvit.club"),
        ("root", "toor", "admin", "Root Superuser", "root@ccvit.club"),
    ]
    members = [
        ("alice", "alice123", "member", "Alice Fernandes", "alice@ccvit.club"),
        ("bob", "bob123", "member", "Bob Mathew", "bob@ccvit.club"),
        ("carol", "carol123", "member", "Carol D'Souza", "carol@ccvit.club"),
        ("dave", "dave123", "member", "Dave Menon", "dave@ccvit.club"),
        ("erin", "erin123", "member", "Erin Thomas", "erin@ccvit.club"),
        ("frank", "frank123", "member", "Frank Pinto", "frank@ccvit.club"),
        ("grace", "grace123", "member", "Grace Kurian", "grace@ccvit.club"),
    ]
    for u in admins + members:
        c.execute(
            "INSERT INTO users (username, password, role, full_name, email, bio) VALUES (?, ?, ?, ?, ?, ?)",
            (u[0], generate_password_hash(u[1]), u[2], u[3], u[4], f"Hi, I'm {u[3].split()[0]}!"),
        )

    events = [
        ("Welcome Mixer", "Kick-off event for new members.", "2026-11-05", "Seminar Hall A", 1),
        ("CTF Night", "Beginner-friendly capture-the-flag.", "2026-11-18", "Lab 204", 1),
        ("Capstone Demo Day", "Members present their projects.", "2026-12-02", "Auditorium", 2),
    ]
    for e in events:
        c.execute(
            "INSERT INTO events (title, description, event_date, location, created_by) VALUES (?, ?, ?, ?, ?)",
            e,
        )

    conn.commit()
    conn.close()
    print(f"Seeded DB at {db_path}")


if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__))
    run(os.path.join(here, "db", "app.db"))
