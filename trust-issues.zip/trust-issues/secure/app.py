"""
TRUST ISSUES :: SECURED PORTAL
Hardened counterpart of /vulnerable/app.py. Same routes and features; each
fix is tagged FIX-N, mapping to the matching VULN-N in the vulnerable build.
"""
import os
import sqlite3
import time
import secrets
import uuid

from flask import (
    Flask, request, render_template, redirect, url_for,
    flash, jsonify, g, session, abort
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "db", "app.db")
UPLOAD_DIR = os.path.join(BASE_DIR, "static", "uploads")
ALLOWED_EXT = {"png", "jpg", "jpeg", "gif", "pdf", "txt"}

app = Flask(__name__)

# FIX-3 (insecure session management):
# strong random secret key -> Flask's session cookie is signed (itsdangerous)
# and tamper-evident; HttpOnly/SameSite are on by default; we also set an
# absolute expiry and a server-side "session_version" check below so a
# captured cookie stops working the moment the user logs out.
app.secret_key = secrets.token_hex(32)
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    PERMANENT_SESSION_LIFETIME=1800,  # 30 min
)

# FIX-11 (sensitive information exposure): debug mode OFF in the secured build
app.debug = False

# --------------------------------------------------------------------------
# DB helpers
# --------------------------------------------------------------------------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()

# --------------------------------------------------------------------------
# FIX-3 continued: session identity is read ONLY from Flask's signed session
# (never trusted from a client-controlled value), and is re-validated against
# the DB's session_version on every request so logout truly invalidates it.
# --------------------------------------------------------------------------
def current_user():
    uid = session.get("user_id")
    ver = session.get("session_version")
    if uid is None:
        return None
    db = get_db()
    row = db.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
    if not row or row["session_version"] != ver:
        session.clear()
        return None
    return row

def login_required(fn):
    from functools import wraps
    @wraps(fn)
    def wrapper(*a, **kw):
        if not current_user():
            return redirect(url_for("login"))
        return fn(*a, **kw)
    return wrapper

def admin_required(fn):
    from functools import wraps
    @wraps(fn)
    def wrapper(*a, **kw):
        user = current_user()
        if not user:
            return redirect(url_for("login"))
        # FIX-5 (broken function-level authorization): role re-checked
        # server-side, from the DB row, on every admin-only route.
        if user["role"] != "admin":
            abort(403)
        return fn(*a, **kw)
    return wrapper

@app.context_processor
def inject_globals():
    # FIX-9 (CSRF): a per-session random token, required on every
    # state-changing form and verified server-side before the action runs.
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_hex(16)
    return {"user": current_user(), "csrf_token": session["csrf_token"]}

def require_csrf():
    token = request.form.get("csrf_token", "")
    if not token or token != session.get("csrf_token"):
        abort(403, description="Invalid or missing CSRF token")

# --------------------------------------------------------------------------
# FIX-2: rate limiting + account lockout on login (in-memory, per-process;
# see docs/limitations for production-scale notes)
# --------------------------------------------------------------------------
MAX_ATTEMPTS = 5
LOCKOUT_SECONDS = 60

@app.route("/")
def index():
    if not current_user():
        return redirect(url_for("login"))
    return render_template("dashboard.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        db = get_db()

        row = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()

        # FIX-2: lockout check, independent of whether the username exists
        # (avoids username enumeration via timing/response differences)
        now = time.time()
        if row and row["locked_until"] and row["locked_until"] > now:
            wait = int(row["locked_until"] - now)
            flash(f"Account temporarily locked. Try again in {wait}s.", "error")
            return render_template("login.html")

        # FIX-1 (SQL Injection): parameterized query above -- username/password
        # are bound as parameters, never concatenated into SQL text.
        if row and check_password_hash(row["password"], password):
            db.execute("UPDATE users SET failed_attempts = 0, locked_until = 0 WHERE id = ?", (row["id"],))
            db.commit()
            session.clear()
            session.permanent = True
            session["user_id"] = row["id"]
            session["session_version"] = row["session_version"]
            flash("Login successful", "ok")
            return redirect(url_for("index"))
        else:
            if row:
                attempts = row["failed_attempts"] + 1
                locked_until = 0
                if attempts >= MAX_ATTEMPTS:
                    locked_until = now + LOCKOUT_SECONDS
                    flash(f"Too many failed attempts. Locked for {LOCKOUT_SECONDS}s.", "error")
                else:
                    flash("Invalid username or password", "error")
                db.execute("UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?",
                           (attempts, locked_until, row["id"]))
                db.commit()
            else:
                flash("Invalid username or password", "error")
    return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        email = request.form.get("email", "")
        if len(password) < 6:
            flash("Password must be at least 6 characters", "error")
            return render_template("register.html")
        db = get_db()
        try:
            db.execute(
                "INSERT INTO users (username, password, role, email, bio) VALUES (?, ?, 'member', ?, ?)",
                (username, generate_password_hash(password), email, f"Hi, I'm {username}!")
            )
            db.commit()
        except sqlite3.IntegrityError:
            flash("Username already taken", "error")
            return render_template("register.html")
        flash("Account created, please log in", "ok")
        return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/logout")
def logout():
    user = current_user()
    if user:
        # FIX-3: bump session_version server-side so any other copy of this
        # user's session cookie (stolen, synced, or saved before logout) is
        # immediately rejected by current_user() above.
        db = get_db()
        db.execute("UPDATE users SET session_version = session_version + 1 WHERE id = ?", (user["id"],))
        db.commit()
    session.clear()
    return redirect(url_for("login"))

# --------------------------------------------------------------------------
# Profiles -- FIX-4 (IDOR): ownership/role check before returning any data
# --------------------------------------------------------------------------
@app.route("/profile/<int:uid>")
@login_required
def profile(uid):
    user = current_user()
    if user["id"] != uid and user["role"] != "admin":
        abort(403)
    db = get_db()
    profile_row = db.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
    if not profile_row:
        return "User not found", 404
    regs = db.execute("""
        SELECT r.id, r.notes, e.title FROM registrations r
        JOIN events e ON e.id = r.event_id
        WHERE r.user_id = ?
    """, (uid,)).fetchall()
    return render_template("profile.html", profile=profile_row, registrations=regs)

@app.route("/profile/<int:uid>/bio", methods=["POST"])
@login_required
def edit_bio(uid):
    require_csrf()
    user = current_user()
    if user["id"] != uid and user["role"] != "admin":
        abort(403)
    # FIX-8 (stored XSS): raw bio is stored as-is but the template no longer
    # renders it with |safe, so Jinja2 auto-escapes it on output.
    bio = request.form.get("bio", "")
    db = get_db()
    db.execute("UPDATE users SET bio = ? WHERE id = ?", (bio, uid))
    db.commit()
    flash("Bio updated", "ok")
    return redirect(url_for("profile", uid=uid))

@app.route("/registration/<int:rid>")
@login_required
def registration(rid):
    user = current_user()
    db = get_db()
    reg = db.execute("""
        SELECT r.*, u.username, e.title FROM registrations r
        JOIN users u ON u.id = r.user_id
        JOIN events e ON e.id = r.event_id
        WHERE r.id = ?
    """, (rid,)).fetchone()
    if not reg:
        return "Not found", 404
    # FIX-4: ownership/role check
    if reg["user_id"] != user["id"] and user["role"] != "admin":
        abort(403)
    return render_template("registration.html", reg=reg)

# --------------------------------------------------------------------------
# Events
# --------------------------------------------------------------------------
@app.route("/events")
@login_required
def events():
    db = get_db()
    rows = db.execute("SELECT * FROM events").fetchall()
    return render_template("events.html", events=rows)

@app.route("/events/<int:eid>")
@login_required
def event_detail(eid):
    db = get_db()
    event = db.execute("SELECT * FROM events WHERE id = ?", (eid,)).fetchone()
    if not event:
        return "Not found", 404
    comments = db.execute("""
        SELECT c.*, u.username FROM comments c JOIN users u ON u.id = c.user_id
        WHERE c.event_id = ? ORDER BY c.id DESC
    """, (eid,)).fetchall()
    return render_template("event_detail.html", event=event, comments=comments)

@app.route("/events/<int:eid>/register", methods=["POST"])
@login_required
def event_register(eid):
    require_csrf()
    user = current_user()
    db = get_db()
    db.execute("INSERT INTO registrations (user_id, event_id, notes) VALUES (?, ?, '')", (user["id"], eid))
    db.commit()
    flash("Registered for event", "ok")
    return redirect(url_for("event_detail", eid=eid))

@app.route("/events/<int:eid>/comment", methods=["POST"])
@login_required
def event_comment(eid):
    require_csrf()
    user = current_user()
    content = request.form.get("content", "")
    db = get_db()
    # FIX-8: stored as-is, escaped on render (template no longer uses |safe)
    db.execute("INSERT INTO comments (event_id, user_id, content) VALUES (?, ?, ?)", (eid, user["id"], content))
    db.commit()
    return redirect(url_for("event_detail", eid=eid))

# --------------------------------------------------------------------------
# Admin -- FIX-5 (role enforced via admin_required), FIX-9 (CSRF token)
# --------------------------------------------------------------------------
@app.route("/admin")
@admin_required
def admin():
    db = get_db()
    ev = db.execute("SELECT * FROM events").fetchall()
    return render_template("admin.html", events=ev)

@app.route("/admin/users")
@admin_required
def admin_users():
    db = get_db()
    users = db.execute("SELECT * FROM users").fetchall()
    return render_template("admin_users.html", users=users)

@app.route("/admin/delete_event/<int:eid>", methods=["POST"])
@admin_required
def admin_delete_event(eid):
    require_csrf()  # FIX-9
    db = get_db()
    db.execute("DELETE FROM events WHERE id = ?", (eid,))
    db.commit()
    flash(f"Event {eid} deleted", "ok")
    return redirect(url_for("admin"))

# --------------------------------------------------------------------------
# FIX-6: robots.txt no longer advertises sensitive paths. Real protection is
# the admin_required decorator on the routes themselves, not a hidden URL.
# --------------------------------------------------------------------------
@app.route("/robots.txt")
def robots():
    content = "User-agent: *\nDisallow: /static/uploads/\n"
    return app.response_class(content, mimetype="text/plain")

# --------------------------------------------------------------------------
# FIX-7 (unrestricted upload) + FIX-10 (path traversal)
# --------------------------------------------------------------------------
def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXT

@app.route("/upload", methods=["GET", "POST"])
@login_required
def upload():
    user = current_user()
    db = get_db()
    if request.method == "POST":
        require_csrf()
        f = request.files.get("file")
        if f and f.filename:
            safe_name = secure_filename(f.filename)
            if not allowed_file(safe_name):
                flash("File type not allowed. Only png/jpg/jpeg/gif/pdf/txt accepted.", "error")
                return redirect(url_for("upload"))
            # FIX-7: randomized stored filename -- original name kept only as
            # display metadata, never used to resolve a filesystem path
            ext = safe_name.rsplit(".", 1)[1].lower()
            stored_name = f"{uuid.uuid4().hex}.{ext}"
            os.makedirs(UPLOAD_DIR, exist_ok=True)
            f.save(os.path.join(UPLOAD_DIR, stored_name))
            db.execute(
                "INSERT INTO uploads (user_id, filename, original_name) VALUES (?, ?, ?)",
                (user["id"], stored_name, f.filename)
            )
            db.commit()
            flash("File uploaded", "ok")
            return redirect(url_for("upload"))
    files = db.execute("""
        SELECT up.*, u.username FROM uploads up JOIN users u ON u.id = up.user_id ORDER BY up.id DESC
    """).fetchall()
    return render_template("upload.html", files=files)

@app.route("/uploads/<path:filename>")
@login_required
def serve_upload(filename):
    # FIX-10: resolve the real path and verify it is still inside UPLOAD_DIR
    # before serving -- rejects any ../ or encoded traversal attempt.
    requested = os.path.realpath(os.path.join(UPLOAD_DIR, filename))
    upload_root = os.path.realpath(UPLOAD_DIR)
    if not requested.startswith(upload_root + os.sep):
        abort(403)
    if not os.path.exists(requested):
        return "File not found", 404
    from flask import send_file
    return send_file(requested)

# --------------------------------------------------------------------------
# FIX-11: no debug endpoint, no stack traces; generic error pages
# --------------------------------------------------------------------------
@app.errorhandler(403)
def forbidden(e):
    return render_template_string_403(), 403

def render_template_string_403():
    return "<h2>403 Forbidden</h2><p>You do not have permission to view this resource.</p>"

@app.errorhandler(404)
def not_found(e):
    return "<h2>404 Not Found</h2>", 404

@app.errorhandler(500)
def server_error(e):
    # generic message only -- no stack trace, no file paths, logged server-side instead
    app.logger.exception("Unhandled server error")
    return "<h2>Something went wrong.</h2><p>The error has been logged. Please try again later.</p>", 500

# --------------------------------------------------------------------------
# FIX-12/13/14/15: guarded chatbot
# --------------------------------------------------------------------------
@app.route("/chatbot", methods=["GET", "POST"])
@login_required
def chatbot():
    user = current_user()
    db = get_db()
    history = app.config.setdefault("CHAT_HISTORY", {}).setdefault(user["id"], [])

    if request.method == "POST":
        require_csrf()
        message = request.form.get("message", "")
        answer = bot_reply(message, db)
        history.append({"q": message, "a": answer})

    doc = db.execute("SELECT * FROM chat_documents ORDER BY id DESC LIMIT 1").fetchone()
    return render_template("chatbot.html", history=history, doc_content=doc["content"] if doc else "")

# FIX-12/13: the bot has NO code path that can return credentials, emails, or
# other member PII, regardless of what the user types. There is nothing to
# "jailbreak" into, because the capability simply does not exist server-side.
# FIX-15: event questions are answered ONLY from a verified DB lookup; if
# nothing matches, the bot says so explicitly instead of inventing details.
EVENT_KEYWORDS = ("event", "schedule", "when is")

def bot_reply(message, db):
    lower = message.lower()

    if "member" in lower and ("list" in lower or "all" in lower or "password" in lower or "email" in lower):
        return "I can't share member records (passwords, emails, or personal notes) — that information is private to each member and club admins."

    if any(k in lower for k in EVENT_KEYWORDS):
        row = None
        for word in message.split():
            clean = "".join(ch for ch in word if ch.isalnum())
            if not clean:
                continue
            row = db.execute("SELECT * FROM events WHERE title LIKE ?", (f"%{clean}%",)).fetchone()
            if row:
                break
        if row:
            return f"'{row['title']}' is scheduled for {row['event_date']}. {row['description']}"
        return ("I don't have a confirmed event matching that in our records. "
                "Please check the Events page or ask a club admin — I won't guess at details I can't verify.")

    return "Hi! I'm the club bot. Ask me about events, membership, or the club handbook."

@app.route("/chatbot/upload_doc", methods=["POST"])
@login_required
def chatbot_upload_doc():
    require_csrf()
    content = request.form.get("content", "")
    db = get_db()
    db.execute("INSERT INTO chat_documents (filename, content) VALUES (?, ?)", ("handbook_update.txt", content))
    db.commit()
    flash("Document updated", "ok")
    return redirect(url_for("chatbot"))

@app.route("/chatbot/summarize", methods=["POST"])
@login_required
def chatbot_summarize():
    require_csrf()
    user = current_user()
    db = get_db()
    doc = db.execute("SELECT * FROM chat_documents ORDER BY id DESC LIMIT 1").fetchone()
    content = doc["content"] if doc else ""

    # FIX-14 (indirect prompt injection): document content is treated purely
    # as DATA to summarize. There is no code path that scans retrieved
    # document text for "instructions" and acts on them -- summarization is
    # a fixed, non-executable operation (truncate + display), so embedded
    # text like "[SYSTEM OVERRIDE ...]" is just inert text in the summary.
    history = app.config.setdefault("CHAT_HISTORY", {}).setdefault(user["id"], [])
    answer = "Summary: " + (content[:150] + ("..." if len(content) > 150 else ""))
    history.append({"q": "(auto) Summarize the reference document", "a": answer})
    return redirect(url_for("chatbot"))

if __name__ == "__main__":
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    if not os.path.exists(DB_PATH):
        import init_db
        init_db.run(DB_PATH)
    app.run(host="0.0.0.0", port=5001, debug=False)
