# Security Assessment Report — "Trust Issues"
**Target:** CC-VIT Club Portal (local demo build)
**Scope:** `vulnerable/` build, `localhost:5000`, authorized local testing only
**Date:** October 2026
**Assessor:** Internal club recruitment exercise (CC-VIT Cybersecurity Club)

## 1. Executive Summary

The club portal's developers claimed the application was secure because
users must authenticate before using it. This assessment shows that claim
is false: **authentication was never the control doing the actual work.**
Fifteen distinct vulnerabilities were identified across authentication,
session handling, access control, input handling, file management, and a
newly added AI chatbot feature. Twelve of the fifteen allow a logged-in
member with zero special privileges to fully compromise other members'
data or escalate to admin-equivalent access; one (SQL injection) defeats
authentication entirely; two (robots.txt disclosure, info exposure) leak
internal details that make every other finding easier to exploit.

All fifteen were reproduced locally, then fixed, then re-tested to confirm
the same attacks no longer succeed. Full technical detail is in
`vulnerabilities.md`; raw command transcripts are in `poc-walkthrough.md`.

## 2. Methodology

Manual, source-aware testing against a self-hosted instance — no
automated scanner was used as a substitute for understanding *why* each
flaw exists. For each finding: (1) identify the vulnerable code path, (2)
construct a minimal exploit with `curl` / a browser PoC page, (3) confirm
impact against seeded demo data, (4) patch the specific root cause, (5)
re-run the identical exploit against the patched build and confirm failure.

## 3. Findings Overview

| ID | Finding | Severity | Privilege required (vulnerable) | Privilege required (secured) |
|---|---|---|---|---|
| 1 | SQL Injection (login bypass) | **Critical** | None | N/A — blocked |
| 2 | Brute Force (no lockout) | High | None | N/A — locked after 5 attempts |
| 3 | Insecure Session Management | High | Any valid/stolen token | N/A — invalidated on logout |
| 4 | IDOR (profile/registration) | High | Any member | N/A — 403 |
| 5 | Broken Function-Level Auth | **Critical** | Any member | N/A — 403 |
| 6 | robots.txt Disclosure | Low (enabler) | None | N/A — nothing sensitive listed |
| 7 | Unrestricted File Upload | High | Any member | N/A — rejected |
| 8 | Stored XSS | High | Any member | N/A — escaped |
| 9 | CSRF | High | Victim must be logged-in admin | N/A — 403 without token |
| 10 | Path Traversal | High | Any member | N/A — 403 |
| 11 | Sensitive Info Exposure (debug) | Medium | None | N/A — generic errors |
| 12 | Direct Prompt Injection | Medium | Any member | N/A — no PII path exists |
| 13 | AI Sensitive Info Disclosure | High | Any member | N/A — no PII path exists |
| 14 | Indirect Prompt Injection | Medium | Any member | N/A — docs never parsed as commands |
| 15 | AI Hallucination | Low/Medium | Any member | N/A — DB-verified only |

Severity is rated by ease of exploitation combined with impact on
confidentiality/integrity of other users' data, using a simple
Critical/High/Medium/Low scale rather than a formal CVSS calculation,
since this is a locally-scoped educational assessment rather than a
production engagement.

## 4. Key Chains Worth Calling Out

Two findings compound into attacks worse than their individual severity:

- **#6 → #5:** `robots.txt` hands an unauthenticated visitor the exact URL
  of the admin panel; #5's missing role check means that visit alone is
  enough to gain full admin functionality. Hiding a URL is not a
  substitute for checking who's allowed to use it.
- **#8 → #3:** Stored XSS executes in victims' browsers; the session
  cookie has no `HttpOnly` flag, so the same payload that defaces a
  profile can just as easily exfiltrate `document.cookie` to an attacker,
  turning a UI bug into full session takeover.
- **#4 is the "silent" one:** unlike XSS or SQLi, IDOR produces no errors,
  no warnings, no logs — it just quietly returns data it shouldn't. In a
  real deployment this is often the hardest class of bug to notice from
  monitoring alone, which is why ownership checks need to be structural
  (a decorator or helper used everywhere), not something developers
  remember route-by-route.

## 5. Remediation Summary

Every finding was fixed with the smallest change that addresses its root
cause (see `vulnerabilities.md` for the fix tied to each item):
parameterized SQL, server-tracked login attempts, signed+invalidatable
sessions, ownership/role checks on every resource-returning route, a real
`admin_required` decorator, a non-revealing `robots.txt`, an upload
allowlist with randomized storage names, Jinja2 auto-escaping restored,
CSRF tokens on all state-changing POSTs, path-containment validation,
debug mode disabled with generic error handling, and — for the chatbot —
removing any server-side code path capable of returning member PII or
treating retrieved text as executable instructions, plus DB-verified-only
answers for factual questions.

## 6. Residual Risk / Out of Scope

This remains a teaching build, not a production system. See
`assumptions-and-limitations.md` for the full list of what the secured
build still does **not** attempt to solve (e.g., no TLS, no real
distributed session store, no production-grade rate limiting
infrastructure, no formal LLM safety layer beyond the rule-based demo bot).

## 7. Conclusion

"Users must log in" was true in both builds. Only one of them was
actually secure. The difference was never the login form — it was
whether every subsequent request re-checked *who* was asking and *what
they were allowed to touch*. That is the core lesson this exercise
was built to demonstrate.
