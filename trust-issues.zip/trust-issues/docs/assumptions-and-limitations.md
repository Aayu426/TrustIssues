# Security Assumptions & Remaining Limitations

This document covers what the **secured build** (`secure/`, port 5001)
does and does not guarantee. It is a teaching artifact for a club
recruitment exercise, not a production-ready application — the goal was
to correctly fix the 15 specific vulnerabilities in scope, not to build a
hardened system from first principles.

## Assumptions made

- **Trusted local network.** Both builds are assumed to run on
  `localhost` / an isolated Docker network for demonstration only. Neither
  build is intended to ever be exposed to the public internet.
- **Seeded, disposable data.** All member/admin accounts and passwords
  (`alice/alice123`, `admin1/admin123`, etc.) are dummy demo data, printed
  openly in the README and login page. None of this represents real
  credentials or real people.
- **Single-process, single-instance deployment.** The secured app assumes
  one running process with no horizontal scaling, so an in-memory/SQLite
  approach to session versioning and rate-limit counters is adequate for
  the demo. A production system would need a shared store (Redis, etc.)
  for these to work correctly across multiple app instances.
- **The grader/attacker has shell access to both builds.** PoCs assume
  `curl` and a local browser are available, consistent with the
  "authorized local testing only" scope stated in the task brief.
- **The chatbot is explicitly out-of-band from any real LLM.** It is a
  small rule-based responder built to *illustrate* prompt-injection-style
  failure modes cheaply and reproducibly, not a wrapper around a
  production language model. Conclusions about "prompt injection" here
  are about the architectural pattern (untrusted input/data being treated
  as instructions), which generalizes to real LLM integrations, but the
  specific keyword-matching implementation is not a stand-in for how a
  real model would behave.

## What is NOT fixed / out of scope

These are real gaps in the secured build, left as-is because they are
outside the 15 vulnerabilities this exercise targets, or because fixing
them properly needs infrastructure beyond a local demo:

- **No TLS/HTTPS.** Both builds run on plain HTTP. In a real deployment,
  cookies marked `Secure` require HTTPS to be transmitted at all; the
  secured build does not set `Secure` on its session cookie for this
  reason (it would break local HTTP testing). This should be enabled the
  moment the app leaves `localhost`.
- **No centralized rate limiting / WAF.** FIX-2 only limits login
  attempts for the `/login` endpoint, per-account. There is no general
  request-rate limiting (e.g., to slow down the IDOR ID-enumeration
  pattern itself, which is now blocked by authorization but could still
  be hammered as a denial-of-service vector).
- **No password complexity enforcement** beyond a 6-character minimum on
  `/register` — not part of the 15-item scope, but a real deployment
  should add it.
- **No audit logging.** The secured build does not log who accessed what,
  which would matter for incident response in a real system.
- **No CSRF protection via a vetted library.** The CSRF token
  implementation here is a minimal, from-scratch, per-session random
  token comparison for teaching clarity. A production app should use a
  maintained library (e.g., Flask-WTF/Flask-SeaSurf) which also handles
  edge cases like token rotation and double-submit patterns more robustly.
- **No dependency/SCA scanning, no CI pipeline.** `requirements.txt`
  pins specific versions but nothing here automatically checks them
  against a CVE database.
- **The chatbot's "fix" is a lack of capability, not a learned safety
  boundary.** A real LLM-backed assistant would need actual prompt
  hardening, output filtering, and retrieval/instruction separation at
  the model-integration layer — removing hardcoded PII access from a
  rule-based bot is not equivalent to solving prompt injection against a
  real language model, which remains an open problem industry-wide.
- **Session store is in-memory/DB-backed, not distributed.** Restarting
  the Flask process clears the `SESSIONS`-equivalent state in the
  vulnerable build; the secured build's DB-backed `session_version`
  survives restarts, but neither is built for multi-instance deployment.
- **File upload storage is local disk**, not validated against malicious
  file *content* beyond extension checking (e.g., no magic-byte sniffing,
  no antivirus scanning, no re-encoding of images to strip embedded
  payloads) — sufficient to close VULN-07 as scoped, but not an
  exhaustive upload-security posture.

## Why these limitations are acceptable here

The task brief asks for 15 specific, demonstrable vulnerability classes
with before/after proof — not a certified production deployment. Scoping
the fix to exactly what was broken (and documenting what's still open)
is itself the more honest security practice: claiming a demo app is
"fully secure" after a scoped fix would repeat the same mistake the
original "authentication = security" claim made.
